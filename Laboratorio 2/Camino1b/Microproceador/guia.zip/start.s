.section .text
.global _start

_start:
    # 0x00041000 es el inicio (tope) de la pila en la RAM
    # La pila crece hacia abajo, por lo que usará el espacio 0x00040XXX
    li sp, 0x00041000  
    
    call main          # Salta a tu función main en C

loop_infinito:
    j loop_infinito    # Seguro ante fallos