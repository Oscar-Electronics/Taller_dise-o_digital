#define UART_DATA  *((volatile int*)0x00002018)
#define UART_CTRL  *((volatile int*)0x00002010)

void main() {
    while (1) {
        // Esperar a que el UART esté listo para transmitir (bit 0 del control)
        while (!(UART_CTRL & 0x01)); 
        
        // Enviar una 'X'
        UART_DATA = 'X';

        // Un pequeño delay manual para no saturar
        for (volatile int i = 0; i < 100000; i++);
    }
}